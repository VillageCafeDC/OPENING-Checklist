VILLAGE CAFE MANAGER v1

This folder contains an installable web app.

IMPORTANT:
Opening index.html in the iPhone ChatGPT/Files preview will not run the app.
It must be placed on a simple web host, then opened in Safari.

EASIEST OPTIONS:
1. Netlify Drop: drag this folder or the ZIP onto Netlify Drop from a computer.
2. GitHub Pages: upload these files to a repository and enable Pages.
3. Any existing website host: place the files in a folder and open that URL.

ON IPHONE:
1. Open the hosted URL in Safari.
2. Tap Share.
3. Tap Add to Home Screen.
4. Open the new Village Cafe icon.

The app saves checklist progress and notes on the device.
